
/*
 * Team Id: eYRC-TB#1558
 * Author List: Sahil,Neha,Ekagrata,Manan 
 * File name: buzzer.h
 * Theme: Transporter Bot
 * Functions: buzzer_pin_config(), port_init1(), buzzer_on(), buzzer_off(), initialize_buzzer()
 * Global Variables: 
 */

int encoder_pin1 = 2;						// left position encoder pin1 defined as 2
int encoder_pin2 = 3;						// right position encoder pin2 defined as 3
volatile int ShaftCountRight = 0;			// to keep track of right position encoder 
volatile int ShaftCountLeft = 0;			// to keep track of left position encoder 

/*
 * Function Name: initialize_interrupt()
 * Input: 
 * Output: 
 * Logic: initialize pin 2 and 3 as INPUT pins
 * Example call: initialize_interrupt();
 */

void initialize_interrupt()
{
  cli();									// clears the global interrupts  
  pinMode(2, INPUT);						// left position encoder pin1 set as INPUT pin
  pinMode(3, INPUT);						// right position encoder pin2 set as INPUT pin
  sei();									// enables the global interrupts
}

/*
 * Function Name: counter()
 * Input: 
 * Output: 
 * Logic: call this function on every falling pulse 
 * Example call: counter
 */

void counter()
 {
     ShaftCountRight++;
     ShaftCountLeft++;
 }

/*
 * Function Name: slow_left()
 * Input: 
 * Output: 
 * Logic: rotates bot towards left 
 * Example call: slow_left();
 */

  void slow_left(){
	  analogWrite(46,125);
	  analogWrite(45, 125);
	  digitalWrite(22, HIGH);
	  digitalWrite(23, LOW);
	  digitalWrite(24, HIGH);
	  digitalWrite(25, LOW);
  }
 
 /*
 * Function Name: slow_right()
 * Input: 
 * Output: 
 * Logic: rotates bot towards right 
 * Example call: slow_right();
 */
 
 void slow_right(){
	 analogWrite(46, 125);
	 analogWrite(45, 125);
	 digitalWrite(22, LOW);
	 digitalWrite(23, HIGH);
	 digitalWrite(24, LOW);
	 digitalWrite(25, HIGH);
 }
 
 /*
 * Function Name: slow_left1()
 * Input: 
 * Output: 
 * Logic: rotates bot towards left with less velocity
 * Example call: slow_left1();
 */
 
 void slow_left1(){
	 analogWrite(46, 102);
	 analogWrite(45, 102);
	 digitalWrite(22, HIGH);
	 digitalWrite(23, LOW);
	 digitalWrite(24, HIGH);
	 digitalWrite(25, LOW);
 }

/*
 * Function Name: slow_right1()
 * Input: 
 * Output: 
 * Logic: rotates bot towards right with less velocity 
 * Example call: slow_right1();
 */

void slow_right1(){
	analogWrite(46, 102);
	analogWrite(45, 102);
	digitalWrite(22, LOW);
	digitalWrite(23, HIGH);
	digitalWrite(24, LOW);
	digitalWrite(25, HIGH);
}
 
/*
 * Function Name: stop1()
 * Input: 
 * Output: 
 * Logic: stops the bot
 * Example call: stop1();
 */

void stop1() {
  analogWrite(46, 0);
  analogWrite(45, 0);
  digitalWrite(22, LOW);
  digitalWrite(23, LOW);
  digitalWrite(24, LOW);
  digitalWrite(25, LOW);
}

/*
 * Function Name: left1()
 * Input: 
 * Output: 
 * Logic: rotates the bot towards left
 * Example call: left1();
 */

void left1() {
  analogWrite(46, 150);
  analogWrite(45, 150);
  digitalWrite(22, HIGH);
  digitalWrite(23, LOW);
  digitalWrite(24, HIGH);
  digitalWrite(25, LOW);
}

/*
 * Function Name: right1()
 * Input: 
 * Output: 
 * Logic: rotates the bot towards right
 * Example call: right1();
 */

void right1() {
  analogWrite(46, 150);
  analogWrite(45, 150);
  digitalWrite(22, LOW);
  digitalWrite(23, HIGH);
  digitalWrite(24, LOW);
  digitalWrite(25, HIGH);
}

/*
 * Function Name: forward1()
 * Input: 
 * Output: 
 * Logic: moves bot in forward direction
 * Example call: forward1();
 */

void forward1(){
  analogWrite(46,170) ;
analogWrite(45,170);
digitalWrite(25,LOW);
digitalWrite(24,HIGH);
digitalWrite(23,HIGH);
digitalWrite(22,LOW);
}

/*
 * Function Name: back1()
 * Input: 
 * Output: 
 * Logic: bot moves in backward direction
 * Example call: back1();
 */

void back1(){
  analogWrite(46,170) ;
analogWrite(45,170);
digitalWrite(25,HIGH);
digitalWrite(24,LOW);
digitalWrite(23,LOW);
digitalWrite(22,HIGH);
  }

/*
 * Function Name: angle_rotate()
 * Input: value for bot to rotate
 * Output: 
 * Logic: rotates the bot upto given value
 * Example call: angle_rotate(degrees);
 */

void angle_rotate(unsigned int Degrees)
{
   attachInterrupt(digitalPinToInterrupt(encoder_pin1), counter, FALLING);				// attach interrupts to encoder pin1
   attachInterrupt(digitalPinToInterrupt(encoder_pin2), counter, FALLING);				// attach interrupts to encoder pin2
   

 Degrees = 2*Degrees;
 float ReqdShaftCount = 0;
 unsigned long int ReqdShaftCountInt = 0;

 ReqdShaftCount = (float) Degrees/ 4.090; // division by resolution to get shaft count
 ReqdShaftCountInt = (unsigned int) ReqdShaftCount;

 while (1)
 {
  if((ShaftCountRight >= ReqdShaftCountInt) || (ShaftCountLeft >= ReqdShaftCountInt))
  {
    ShaftCountLeft = 0;
    ShaftCountRight = 0;
  break;
 }
 }
 stop1(); // stop the bot
 delay(200);
}

/*
 * Function Name: linear_distance_mm()
 * Input: value for movement of bot
 * Output: 
 * Logic: value upto which bot will move in forward and backward direction
 * Example call: linear_distance_mm(distanceInMM);
 */

void linear_distance_mm(unsigned int DistanceInMM)
{
  
   attachInterrupt(digitalPinToInterrupt(encoder_pin1), counter, FALLING);				// attach interrupts to encoder pin1
   attachInterrupt(digitalPinToInterrupt(encoder_pin2), counter, FALLING);				// attach interrupts to encoder pin2
   
 float ReqdShaftCount = 0;
 unsigned long int ReqdShaftCountInt = 0;

 DistanceInMM =  2 * DistanceInMM;
 ReqdShaftCount = DistanceInMM / 5.338; // division by resolution to get shaft count
 ReqdShaftCountInt = (unsigned long int) ReqdShaftCount;

while(1)
{
    if((ShaftCountRight >= ReqdShaftCountInt) || (ShaftCountLeft >= ReqdShaftCountInt))
    {
        ShaftCountLeft = 0;
        ShaftCountRight = 0;
        break;
    }
}
stop1();		// stop the bot
delay(200);
}

/*
 * Function Name: forward_move()
 * Input: value for movement of bot
 * Output: 
 * Logic: value upto which bot will move in forward direction
 * Example call: forward_move(distance);
 */

void forward_move(unsigned int distance){

  forward1();														// sets the bot to move in forward direction
  linear_distance_mm(distance);
  detachInterrupt(digitalPinToInterrupt(encoder_pin1));				// detach interrupts to encoder pin1
  detachInterrupt(digitalPinToInterrupt(encoder_pin2));				// detach interrupts to encoder pin2
stop1();
delay(500);
  }

/*
 * Function Name: backward_move()
 * Input: value for movement of bot
 * Output: 
 * Logic: value upto which bot will move in backward direction
 * Example call: backward_move(distance);
 */

void backward_move(unsigned int distance){

  back1();															// sets the bot to move in backward direction
  linear_distance_mm(distance);
  
  detachInterrupt(digitalPinToInterrupt(encoder_pin1));				// detach interrupts to encoder pin1
  detachInterrupt(digitalPinToInterrupt(encoder_pin2));				// detach interrupts to encoder pin2
  stop1();
  delay(500);
  }

/*
 * Function Name: left_rotate()
 * Input: value for left rotation of bot
 * Output: 
 * Logic: value upto which bot will rotate towards left direction
 * Example call: left_roate(degrees);
 */

void left_rotate(unsigned int Degrees){

  left1();															// sets the bot to rotate towards left direction
  angle_rotate(Degrees);
  
  detachInterrupt(digitalPinToInterrupt(encoder_pin1));				// detach interrupts to encoder pin1
  detachInterrupt(digitalPinToInterrupt(encoder_pin2));				// detach interrupts to encoder pin2
  stop1();
  delay(500);

  }
  
 /*
 * Function Name: right_rotate()
 * Input: value for right rotation of bot
 * Output: 
 * Logic: value upto which bot will rotate towards right direction
 * Example call: right_roate(degrees);
 */

 void right_rotate(unsigned int Degrees){

  right1();															// sets the bot to rotate towards right direction
  angle_rotate(Degrees);
  detachInterrupt(digitalPinToInterrupt(encoder_pin1));				// detach interrupts to encoder pin1
  detachInterrupt(digitalPinToInterrupt(encoder_pin2));				// detach interrupts to encoder pin2
  stop1();
  delay(500);
  }


