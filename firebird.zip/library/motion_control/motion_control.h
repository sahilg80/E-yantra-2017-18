/*
 * Team Id: eYRC-TB#1558
 * Author List: Sahil,Neha,Ekagrata,Manan 
 * File name: motion_control.h
 * Theme: Transporter Bot
 * Functions: initialize_motor(), right(),stops(),left(),forward(),back()
 * Global Variables: en1,en2,in1,in2,in3,in4
 */

//left motor
#define en1 46		// pwm pin for motor 'left'
#define in1 22		// pinmode for left1 motor
#define in2 23		// pinmode for left2 motor

//right motor
#define en2 45		// pwm pin motor 'right'
#define in3 24		// pinmode for right1 motor
#define in4 25		// pinmode for right2 motor

/*
 * Function Name: initialize_motor()
 * Input: 
 * Output: 
 * Logic: pins of DC motor are set as output pins
 * Example call: initialize_motor();
 */

void initialize_motor(){
pinMode(25,OUTPUT);			// sets pin 25 as output
pinMode(24,OUTPUT);			// sets pin 24 as output
pinMode(23,OUTPUT);			// sets pin 23 as output
pinMode(22,OUTPUT);			// sets pin 22 as output
// pwm pins
pinMode(46,OUTPUT);			// sets pin 46 as output
pinMode(45,OUTPUT);			// sets pin 45 as output
}

/*
 * Function Name: right()
 * Input: 
 * Output: 
 * Logic: left DC motor of bot rotates in forward direction 
 * Example call: right();
 */

void right(){
  analogWrite(en1,100);			// sets PWM signal to pin 46
  analogWrite(en2,100);			// sets PWM signal to pin 45
  digitalWrite(in1, LOW);		// sets LOW signal to pin 22
  digitalWrite(in2, HIGH);		// sets HIGH signal to pin 23
  digitalWrite(in3, LOW);		// sets LOW signal to pin 24
  digitalWrite(in4, LOW);		// sets LOW signal to pin 25
}

/*
 * Function Name: stops()
 * Input: 
 * Output: 
 * Logic: sets the output of DC motor(left and right) to LOW
 * Example call: stops();
 */

void stops() {
  analogWrite(en1, 0);
  analogWrite(en2, 0);
  digitalWrite(in1, LOW);
  digitalWrite(in2, LOW);
  digitalWrite(in3, LOW);
  digitalWrite(in4, LOW);
}

/*
 * Function Name: left()
 * Input: 
 * Output: 
 * Logic: right DC motor of bot rotates in forward direction 
 * Example call: left();
 */

void left() {
  analogWrite(en1, 100);
  analogWrite(en2, 100);
  digitalWrite(in1, LOW);
  digitalWrite(in2, LOW);
  digitalWrite(in3, HIGH);
  digitalWrite(in4, LOW);
}

/*
 * Function Name: forward()
 * Input: 
 * Output: 
 * Logic: left and right DC motor rotates in forward direction 
 * Example call: forward();
 */

void forward(){
analogWrite(en1,250) ;
analogWrite(en2,250) ;
digitalWrite(in1,LOW);
digitalWrite(in2,HIGH);
digitalWrite(in3,HIGH);
digitalWrite(in4,LOW);
  }
  
 /*
 * Function Name: back()
 * Input: 
 * Output: 
 * Logic: left and right DC motor rotates in backward direction
 * Example call: back();
 */
 
void back(){
analogWrite(en1,150) ;
analogWrite(en2,150) ;
digitalWrite(in1,HIGH);
digitalWrite(in2,LOW);
digitalWrite(in3,LOW);
digitalWrite(in4,HIGH);
  }

