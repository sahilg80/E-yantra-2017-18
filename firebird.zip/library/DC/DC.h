
/*
 * Team Id: eYRC-TB#1558
 * Author List: Sahil,Neha,Ekagrata,Manan 
 * File name: DC.h
 * Theme: Transporter Bot
 * Functions: initialize_belt(), motor_left(), motor_right(), motor_stop(),belt_move()
 * Global Variables: 
 */

/*
 * Function Name: initialize_belt()
 * Input: 
 * Output: 
 * Logic: defines the pinmode for DC motor used for conveyor belt
 * Example call: initialize_belt();
 */

void initialize_belt(){
	pinMode(8,OUTPUT);			// sets the pin 8 as OUTPUT
	pinMode(9,OUTPUT);			// sets the pin 9 as OUTPUT
}

/*
 * Function Name: motor_left()
 * Input: 
 * Output: 
 * Logic: makes the belt move in backward direction
 * Example call: motor_left();
 */

void motor_left()
{
	analogWrite(8,200);		// sets the pin 8 as HIGH
	analogWrite(9,0);		// sets the pin 9 as LOW
}

/*
 * Function Name: motor_right()
 * Input: 
 * Output: 
 * Logic: makes the belt move in forward direction
 * Example call: motor_right();
 */

void motor_right()
{
	analogWrite(8,0);		// sets the pin 8 as LOW
	analogWrite(9,200);		// sets the pin 9 as HIGH
}

/*
 * Function Name: motor_stop()
 * Input: 
 * Output: 
 * Logic: makes the belt stop
 * Example call: motor_stop();
 */

void motor_stop(){
	analogWrite(8,0);			// sets the 8 as LOW
	analogWrite(9,0);			// sets the 9 as LOw
}

/*
 * Function Name: belt_move()
 * Input: 
 * Output: 
 * Logic: makes the belt move in forward direction for 900 milliseconds
 * Example call: belt_move();
 */

void belt_move(){
	motor_right();					
	delay(900);
	motor_stop();
}
